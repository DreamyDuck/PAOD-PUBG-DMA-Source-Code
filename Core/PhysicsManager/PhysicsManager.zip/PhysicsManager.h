#include "PhysicStruct.h"
#include "../Visuals.h"
#ifndef PHYSICS_MANAGER_H
#define PHYSICS_MANAGER_H
//#define DebugTrace
//#define pvdConnect
#define SaveFileToPath

namespace IronMan::Core
{
	using namespace physx;

	class PhysicsManager {
	public:
		PhysicsManager(bool Open);
		~PhysicsManager();
		//���������Ƿ���Ч
		bool IsRigidValid(ptr_t Rigid);
		bool validateIndices(const PxTriangleMeshDesc& meshDesc, const GuTriangleMesh& TriangleMesh);
		//��ʼ��Physx
		void InitPhysX();
		//�������г�Ա
		bool DestroyAllRigidBodies();
		//�ӳ������Ƴ�����
		void RemoveActorFromScene(PxRigidActor* Actor);
		// ���������������ݵ��ļ�
		void saveTriangleMeshToFile(PxTriangleMesh* triangleMesh, const char* filename);
		// ���ļ�����������������
		std::pair<PxTriangleMesh*, void*> loadTriangleMeshFromFile(const char* filename);
		// ����߶ȳ����ݵ��ļ�
		void saveHeightFieldToFile(PxHeightField* heightField, const char* filename);
		// ���ļ����ظ߶ȳ�����
		std::pair <PxHeightField*, void*> loadHeightFieldFromFile(const char* filename);

		//Math
		IronMan::Core::SDK::FVector PxVec3ToFVector(const PxVec3& vec);
		IronMan::Core::SDK::FQuat PxQuatToFQuat(const PxQuat& Quat);
		PxVec3 FVectorToPxVec3(const IronMan::Core::SDK::FVector& vec);
		PxQuat FQuatToPxQuat(const IronMan::Core::SDK::FQuat& Quat);
		PxQuat PxQuat_Multy(physx::PxQuat _this, const physx::PxQuat q);
		PxTransform CalulateDynamicGlobalPose2(PxTransform p_body2Actor, PxTransform p_mBufferedBody2World);
		int computeCellCoordinates(float rowLimit, float colLimit, float nbColumns, float x, float z, float* fracX, float* fracZ);
		float getHeightInternal2(ptr_t Samples, float NumCols, unsigned int vertexIndex, float fracX, float fracZ);
		float getHeightInternal2Cache(VMMDLL_SCATTER_HANDLE handle, ptr_t Samples, float NumCols, unsigned int vertexIndex, float fracX, float fracZ);
		//��ȡ��ǰ���糡��
		void* GetPxScene(__int64 a1, uint32_t* a2, __int16 a3);
		ptr_t GetPhysxSceneFromUWorld(ptr_t world);

		//�ӳ�����ɸѡ��Ҫ���ӵ�����ĸ���
		RigidFreshType FilterDynamicRigid(PxFilterData SimData, int VerticesSize);
		bool checkTransformIsSame(PxRigidActor* Actor, PxTransform Transform);
		//RayCast���ù���Ͷ��
		bool WeaponCanHit(FVector& origin, FVector& direction, float maxDistance = 1000000.f, bool showDebug = false, bool bTrigger = false, bool CarFilter = false);
		//���³������������
		void setGlobalPoseInternal(PxRigidActor* RigidActor, PxTransform Transform);
		//�߳�1
		void InsertTriangleMap(std::shared_ptr<RigiBodyStruct> RigidBody);
		bool UpdateInfoAndCheckPath();
		void ClearInValidRigid(std::unordered_map<ptr_t, std::shared_ptr<RigiBodyStruct>>& RIGIDARRAY, std::unordered_map<ptr_t, std::shared_ptr<int>>& EraseVector);
		void AddRigidBodiesToScene(std::unordered_map<ptr_t, std::shared_ptr<RigiBodyStruct>>& RIGIDARRAY, std::unordered_map<ptr_t, std::shared_ptr<int>>& UpdateArray, std::unordered_map<ptr_t, std::shared_ptr<int>>& EraseVector);
		void UpdateRigidData(VMMDLL_SCATTER_HANDLE ScatterHandle);
		void asyncScenes();
		//�߳�2
		//�������������̬������
		void setActorGlobalPoseInternal(PxRigidDynamic* RigidActor, PxTransform Transform, float radiu, float halfhigh);
		//�����߳�
		void UpdateAlwaysUpdatedRigid(VMMDLL_SCATTER_HANDLE ScatterHandle);
		void UpdateActorRigid();
		void syncScenes();
		//�������
		void DrawRigidBox();
		void DrawSingleRigid(PxRigidActor* Actor);
		//����������Ҫ���Թ���׷�ٵ���ҺͶ�Ӧ����
		inline void SetRayCast(std::unordered_map <ptr_t, std::vector<FVector>> BoneArray)
		{
			unique_writeguard<WfirstRWLock> wlock(RayCastArrayLock);
			std::vector<ptr_t>EraseVec;

			for (auto iter : RayCastArray)
			{
				try
				{
					auto FindResult = BoneArray.find(iter.first);
					if (FindResult == BoneArray.end() && FindResult->first != iter.first)
					{
						EraseVec.push_back(iter.first);
					}
				}
				catch (...)
				{

				}
			}
			for (auto iter : EraseVec)
			{
				auto FindResult = RayCastArray.find(iter);
				if (FindResult != RayCastArray.end())
					RayCastArray.erase(FindResult);
			}
			for (auto iter : BoneArray)
				RayCastArray[iter.first] = std::make_shared<std::vector<FVector>>(iter.second);
		}
		//��ȡ������Ҫ���Թ���׷�ٵ���ҺͶ�Ӧ����
		inline std::vector<std::pair<ptr_t, std::shared_ptr<std::vector<FVector>>>> GetRayCastPtr()
		{
			unique_readguard<WfirstRWLock> rlock(RayCastArrayLock);
			std::vector<std::pair<ptr_t, std::shared_ptr<std::vector<FVector>>>> RetArray;
			if (RayCastArray.size())
				for (auto iter : RayCastArray)
					RetArray.push_back(std::pair(iter.first, iter.second));
			return RetArray;
		}
		//�������׷����ҵ�����
		inline void ClearRayCastArray()
		{
			unique_writeguard<WfirstRWLock> wlock(RayCastArrayLock);
			if (RayCastArray.size())
				RayCastArray.clear();
		}
		//������ҽ����ӳ���
		inline void AddActorResult(ptr_t Actor)
		{
			if (!IsAddrValid(Actor))
				return;
			unique_writeguard<WfirstRWLock> wlock(RayCastResultArrayLock);
			auto FindResult = RayCastResultArray.find(Actor);
			if (FindResult == RayCastResultArray.end())
			{
				RayCastResultArray.emplace(Actor, std::make_shared<std::vector<bool>>());
				RayCastResultArray[Actor]->resize(24);
			}
			else if (FindResult->second && FindResult->second->size() != 24)
				FindResult->second->resize(24);
		}
		//�������ù���׷�ٽ��
		inline void SetActorVisible(ptr_t Actor, int Bone, bool Visible)
		{
			if (!IsAddrValid(Actor))
				return;
			if (Bone >= 24)
				return;
			unique_writeguard<WfirstRWLock> wlock(RayCastResultArrayLock);
			auto FindResult = RayCastResultArray.find(Actor);
			if (FindResult != RayCastResultArray.end() && FindResult->second)
				(*FindResult->second)[Bone] = Visible;
		}
		//�������ù���׷�ٽ��
		inline void SetActorVisibleAll(std::vector<std::pair<ptr_t, std::vector<bool>>>& result)
		{
			unique_writeguard<WfirstRWLock> wlock(RayCastResultArrayLock);
			try
			{
				for (auto iter : result)
				{
					auto FindResult = RayCastResultArray.find(iter.first);
					if (FindResult != RayCastResultArray.end() && FindResult->second)
					{
						if (iter.second.size() > 24)
							continue;
						for (int i = 0; i < FindResult->second->size(); i++)
							(*FindResult->second)[i] = iter.second[i];
					}
				}
			}
			catch (...)
			{

			}
		}
		//�������׷�ٽ������
		inline void ClearActorVisible()
		{
			unique_writeguard<WfirstRWLock> wlock(RayCastResultArrayLock);
			if (RayCastResultArray.size())
				RayCastResultArray.clear();
		}
		//��ѯ����׷�ٽ��
		inline bool GetActorVisible(ptr_t Actor, int Bone)
		{
			if (!IsAddrValid(Actor))
				return true;
			if (Bone >= 24)
				return true;
			unique_readguard<WfirstRWLock> rlock(RayCastResultArrayLock);
			auto FindResult = RayCastResultArray.find(Actor);
			if (FindResult != RayCastResultArray.end())
				return (*FindResult->second)[Bone];
			return false;
		}
		//��ȡȫ����ҵ���̬���塢����
		inline std::unordered_map<ptr_t, std::shared_ptr<CapSuleInfo>> GetRigidActor()
		{
			std::unordered_map<ptr_t, std::shared_ptr<CapSuleInfo>> Ret;
			unique_readguard<WfirstRWLock> rlock(RigidActorLock);
			for (auto iter : RigidActor)
				Ret.emplace(iter.first, iter.second);
			return Ret;
		}
		//���߳�������ҵ���̬���������
		inline void SetRigidActor(std::unordered_map<ptr_t, std::shared_ptr<CapSuleInfo>>& objects)
		{
			unique_writeguard<WfirstRWLock> wlock(RigidActorLock);
			if (objects.empty())
			{
				RigidActor.clear();
				return;
			}
			RigidActor = objects;
			objects.clear();
		}
		//��ѯ��ҵ���̬���������
		inline auto FindRigidActor(ptr_t Actor)
		{
			if (!IsAddrValid(Actor))
				return std::shared_ptr<CapSuleInfo>(new CapSuleInfo(0.f, 0.f, PxTransform(), 0));
			unique_readguard<WfirstRWLock> rlock(RigidActorLock);
			auto FindResult = RigidActor.find(Actor);
			if (FindResult != RigidActor.end())
				return FindResult->second;
			return std::shared_ptr<CapSuleInfo>(new CapSuleInfo(0.f, 0.f, PxTransform(), 0));
		}
		//��ȡEraseMap
		inline std::vector<ptr_t> GetEraseMap()
		{
			unique_readguard<WfirstRWLock> rlock(EraseFromMapArrayLock);
			std::vector<ptr_t>Ret;
			for (auto iter : EraseFromMapArray)
				Ret.push_back(iter.first);
			return Ret;
		}
		//�����ӵĶ����Ĺ���
		inline void AddtoErase(ptr_t point)
		{
			unique_writeguard<WfirstRWLock> wlock(EraseFromMapArrayLock);
			EraseFromMapArray.emplace(point, std::make_shared<int>(1));
		}
		//���EraseMap
		inline void ClearEraseMap()
		{
			unique_writeguard<WfirstRWLock> wlock(EraseFromMapArrayLock);
			EraseFromMapArray.clear();
		}
		//��ѯOutOfMap
		inline bool FindOutOfMap(ptr_t point)
		{
			if (!IsAddrValid(point))
				return true;
			unique_readguard<WfirstRWLock> rlock(OutOfMapLock);
			return OutOfMapWithLock.find(point) != OutOfMapWithLock.end();
		}
		inline void InsertOutOfMap(ptr_t point, std::shared_ptr<RigiBodyStruct> body)
		{
			if (!IsAddrValid(point))
				return;
			unique_writeguard<WfirstRWLock> wlock(OutOfMapLock);
			OutOfMapWithLock.emplace(point, body);
		}
		inline void EraseOutOfMap(ptr_t point)
		{
			if (!IsAddrValid(point))
				return;
			unique_writeguard<WfirstRWLock> wlock(OutOfMapLock);
			auto FindResult = OutOfMapWithLock.find(point);
			if (FindResult != OutOfMapWithLock.end())
				OutOfMapWithLock.erase(FindResult);
		}
		inline void ClearOutOfMap()
		{
			unique_writeguard<WfirstRWLock> wlock(OutOfMapLock);
			if (OutOfMapWithLock.size())
				OutOfMapWithLock.clear();
		}
		//���ҳ������Ѵ��ڵĶ�̬����
		inline PxRigidDynamic* FindDynamicRigidBody(ptr_t point) {
			if (!IsAddrValid(point))
				return nullptr;
			unique_readguard<WfirstRWLock> rlock(dynamicBodiesMapLock);
			auto it = dynamicBodiesMapWithLock.find(point);
			if (it != dynamicBodiesMapWithLock.end()) {
				return it->second;
			}
			return nullptr;
		}
		//�Ƴ��������Ѵ��ڵĶ�̬����
		inline void EraseDynamicRigidBody(ptr_t point) {
			if (!IsAddrValid(point))
				return;
			unique_writeguard<WfirstRWLock> wlock(dynamicBodiesMapLock);
			auto FindResult = dynamicBodiesMapWithLock.find(point);
			if (FindResult != dynamicBodiesMapWithLock.end())
				dynamicBodiesMapWithLock.erase(FindResult);
		}
		//���Ӷ�̬���嵽ӳ���
		inline void InsertDynamicRigidBody(ptr_t Point, PxRigidDynamic* Actor)
		{
			if (!IsAddrValid(Point) || Utils::IsSafeReadPtr(Actor, 8))
				return;
			unique_writeguard<WfirstRWLock> wlock(dynamicBodiesMapLock);
			dynamicBodiesMapWithLock.emplace(Point, Actor);
		}
		//�����̬����ӳ���
		inline void ClearDynamicRigidBody()
		{
			unique_writeguard<WfirstRWLock> wlock(dynamicBodiesMapLock);
			if (dynamicBodiesMapWithLock.size())
				dynamicBodiesMapWithLock.clear();
		}
		//���ҳ������Ѵ��ڵľ�̬����
		inline PxRigidStatic* FindStaticRigidBody(ptr_t point) {
			if (!IsAddrValid(point))
				return false;
			unique_readguard<WfirstRWLock> rlock(staticBodiesMapLock);
			auto it = staticBodiesMapWithLock.find(point);
			if (it != staticBodiesMapWithLock.end()) {
				return it->second;
			}
			return nullptr;
		}
		//�Ƴ��������Ѵ��ڵľ�̬����
		inline void EraseStaticRigidBody(ptr_t point) {
			if (!IsAddrValid(point))
				return;
			unique_writeguard<WfirstRWLock> wlock(staticBodiesMapLock);
			auto FindResult = staticBodiesMapWithLock.find(point);
			if (FindResult != staticBodiesMapWithLock.end())
				staticBodiesMapWithLock.erase(FindResult);
		}
		//���Ӿ�̬���嵽ӳ���
		inline void InsertStaticRigidBody(ptr_t Point, PxRigidStatic* Actor)
		{
			if (!IsAddrValid(Point) || Utils::IsSafeReadPtr(Actor, 8))
				return;
			unique_writeguard<WfirstRWLock> wlock(staticBodiesMapLock);
			staticBodiesMapWithLock.emplace(Point, Actor);
		}
		//�����̬����ӳ���
		inline void ClearStaticRigidBody()
		{
			unique_writeguard<WfirstRWLock> wlock(staticBodiesMapLock);
			if (staticBodiesMapWithLock.size())
				staticBodiesMapWithLock.clear();
		}

		//���߳��߳����ӵĶ�̬���� ֻ�н��Һ�Բ��
		inline std::shared_ptr<PxRigidDynamic*> FindDynamicActorRigid(ptr_t point) {
			if (!IsAddrValid(point))
				return std::make_shared<PxRigidDynamic*>(nullptr);
			unique_readguard<WfirstRWLock> rlock(dynamicActorMapLock);
			auto it = dynamicActorMap.find(point);
			if (it != dynamicActorMap.end()) {
				return it->second;
			}
			return std::make_shared<PxRigidDynamic*>(nullptr);
		}
		//���ӽ��Һ�Բ�ε�ӳ���
		inline void InsertDynamicActorRigid(ptr_t point, std::shared_ptr<PxRigidDynamic*> Actor)
		{
			if (!IsAddrValid(point) || !Actor || Utils::IsSafeReadPtr(*Actor, 8))
				return;
			unique_writeguard<WfirstRWLock> wlock(dynamicActorMapLock);
			dynamicActorMap.emplace(point, Actor);
		}

		inline void ClearDynamicActorRigid()
		{
			unique_writeguard<WfirstRWLock> wlock(dynamicActorMapLock);
			if (dynamicActorMap.size())
				dynamicActorMap.clear();
		}

		inline auto GetAlreadyLoadedTriangle(hash_t Name)
		{
			unique_readguard<WfirstRWLock> rlock(AlreadyLoadedTriangleLock);
			auto FindResult = AlreadyLoadedTriangle.find(Name);
			if (FindResult != AlreadyLoadedTriangle.end())
				return FindResult->second;
			return std::make_shared<std::pair<PxTriangleMesh*, void*>>(std::make_pair(nullptr, nullptr));
		}

		inline void InsertAlreadyLoadedTriangle(hash_t Name, std::pair<PxTriangleMesh*, void*> Triangle)
		{
			unique_writeguard<WfirstRWLock> wlock(AlreadyLoadedTriangleLock);
			AlreadyLoadedTriangle.emplace(Name, std::make_shared<std::pair<PxTriangleMesh*, void*>>(Triangle));
		}

		inline void ClearAlreadyLoadedTriangle()
		{
			unique_writeguard<WfirstRWLock> wlock(AlreadyLoadedTriangleLock);
			if (AlreadyLoadedTriangle.size())
			{
				for (auto iter : AlreadyLoadedTriangle)
				{
					if (!iter.second)
						continue;
					if (IsRigidValid((ptr_t)iter.second->first))
					{
						iter.second->first->release();
						if (!Utils::IsSafeReadPtr(iter.second->second, 8))
							free(iter.second->second);
					}
				}
				AlreadyLoadedTriangle.clear();
			}
		}

		inline auto GetAlreadyLoadedHeightField(hash_t Name)
		{
			unique_readguard<WfirstRWLock> rlock(AlreadyLoadedHeightFieldLock);
			auto FindResult = AlreadyLoadedHeightField.find(Name);
			if (FindResult != AlreadyLoadedHeightField.end())
				return FindResult->second;
			return std::make_shared<std::pair<PxHeightField*, void*>>(std::make_pair(nullptr, nullptr));
		}

		inline void InsertAlreadyLoadedHeightField(hash_t Name, std::pair<PxHeightField*, void*> HeightField)
		{
			unique_writeguard<WfirstRWLock> wlock(AlreadyLoadedHeightFieldLock);
			AlreadyLoadedHeightField.emplace(Name, std::make_shared<std::pair<PxHeightField*, void*>>(HeightField));
		}

		inline void ClearAlreadyLoadedHeightField()
		{
			unique_writeguard<WfirstRWLock> wlock(AlreadyLoadedHeightFieldLock);
			if (AlreadyLoadedHeightField.size())
			{
				for (auto iter : AlreadyLoadedHeightField)
				{
					if (!iter.second)
						continue;
					if (IsRigidValid((ptr_t)iter.second->first))
					{
						iter.second->first->release();
						if (!Utils::IsSafeReadPtr(iter.second->second, 8))
							free(iter.second->second);
					}
				}
				AlreadyLoadedHeightField.clear();
			}
		}

		inline ptr_t FindCurrentSceneActor(ptr_t point) {
			if (!IsAddrValid(point))
				return 0;
			unique_readguard<WfirstRWLock> rlock(CurrentSceneActorLock);
			auto it = CurrentSceneActorWithLock.find(point);
			if (it != CurrentSceneActorWithLock.end()) {
				return it->first;
			}

			return 0;
		}
		inline void InsertCurrentSceneActor(ptr_t point) {
			if (!IsAddrValid(point))
				return;
			unique_writeguard<WfirstRWLock> wlock(CurrentSceneActorLock);
			CurrentSceneActorWithLock.emplace(point, std::make_shared<int>(1));
		}
		inline void ClearCurrentSceneActor() {
			unique_writeguard<WfirstRWLock> wlock(CurrentSceneActorLock);
			CurrentSceneActorWithLock.clear();
		}

		inline void InsertAllcateMemory(void* Memory)
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentAllocateMemoryLock);
			CurrentAllocateMemory.emplace(Memory, std::make_shared<int>(1));
		}

		inline bool IsInAllocateMemory(void* Memory)
		{
			unique_readguard<WfirstRWLock> rlock(CurrentAllocateMemoryLock);
			return CurrentAllocateMemory.find(Memory) != CurrentAllocateMemory.end();
		}

		inline bool EraseAllocateMemory(void* Memory)
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentAllocateMemoryLock);
			auto FindResult = CurrentAllocateMemory.find(Memory);
			if (FindResult != CurrentAllocateMemory.end())
			{
				if (!Utils::IsSafeReadPtr(FindResult->first, 8))
					delete FindResult->first;
				CurrentAllocateMemory.erase(FindResult);
				return true;
			}
			return false;
		}

		inline void ClearAllocateMemrory()
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentAllocateMemoryLock);
			for (auto iter : CurrentAllocateMemory)
			{
				if (!Utils::IsSafeReadPtr(iter.first, 8))
					delete iter.first;
			}
			CurrentAllocateMemory.clear();
		}

		inline auto GetAllocateMemory()
		{
			unique_readguard<WfirstRWLock> rlock(CurrentAllocateMemoryLock);
			return CurrentAllocateMemory;
		}

		inline void InsertDeleteMemory(void* Memory)
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentDeleteMemoryLock);
			CurrentDeleteMemory.emplace(Memory, std::make_shared<int>(1));
		}

		inline bool IsInDeleteMemory(void* Memory)
		{
			unique_readguard<WfirstRWLock> rlock(CurrentDeleteMemoryLock);
			return CurrentDeleteMemory.find(Memory) != CurrentDeleteMemory.end();
		}

		inline void EraseDeleteMemory(void* Memory)
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentDeleteMemoryLock);
			auto FindResult = CurrentDeleteMemory.find(Memory);
			if (FindResult != CurrentDeleteMemory.end())
				CurrentDeleteMemory.erase(FindResult);
			return;
		}

		inline void ClearDeleteMemrory()
		{
			unique_writeguard<WfirstRWLock> wlock(CurrentDeleteMemoryLock);
			CurrentDeleteMemory.clear();
		}

		inline auto GetDeleteMemory()
		{
			unique_readguard<WfirstRWLock> rlock(CurrentDeleteMemoryLock);
			return CurrentDeleteMemory;
		}

		bool IsSceneCreate();
		inline auto GetPhysx() { return this; };
	private:
		// Global PhysX objects
		PxDefaultAllocator gAllocator;
		PxDefaultErrorCallback gErrorCallback;
		PxFoundation* gFoundation;
		PxPhysics* gPhysics;
		PxCooking* gCooking;
		PxDefaultCpuDispatcher* gDispatcher;
		WfirstRWLock gSceneLock;
		physx::PxScene* gScene;
		PxMaterial* gMaterial;
		PxPvd* gPvd;
		//�����Ƿ񴴽�
		bool bSceneCreate;
		//Px64ģ��ͷ��ַ��β��ַ
		ptr_t Px64Base = 0;
		ptr_t Px64End = 0;
		ptr_t PxCommonBase = 0;
		ptr_t PxCommonEnd = 0;
		ptr_t PxCookingBase = 0;
		ptr_t PxCookingEnd = 0;
		//�����̴߳���RigidActor����̬����洢������
		WfirstRWLock RigidActorLock;
		std::unordered_map<ptr_t, std::shared_ptr<CapSuleInfo>>RigidActor;
		//���߳�ʹ����
		WfirstRWLock dynamicActorMapLock;
		std::unordered_map<ptr_t, std::shared_ptr<PxRigidDynamic*>> dynamicActorMap;
		//���߳�ʹ����
		WfirstRWLock dynamicBodiesMapLock;
		std::unordered_map<ptr_t, PxRigidDynamic*> dynamicBodiesMapWithLock;
		//���߳�ʹ����
		WfirstRWLock staticBodiesMapLock;
		std::unordered_map<ptr_t, PxRigidStatic*> staticBodiesMapWithLock;
		//���߳�ʹ����
		WfirstRWLock OutOfMapLock;
		std::unordered_map<ptr_t, std::shared_ptr<RigiBodyStruct>> OutOfMapWithLock;
		//���߳�ʹ����
		WfirstRWLock AlreadyLoadedTriangleLock;
		std::unordered_map<hash_t, std::shared_ptr<std::pair<PxTriangleMesh*, void*>>>AlreadyLoadedTriangle;
		//���߳�ʹ����
		WfirstRWLock AlreadyLoadedHeightFieldLock;
		std::unordered_map<hash_t, std::shared_ptr<std::pair<PxHeightField*, void*>>>AlreadyLoadedHeightField;
		//���߳�ʹ����Ҫʹ����
		WfirstRWLock EraseFromMapArrayLock;
		std::unordered_map<ptr_t, std::shared_ptr<int>> EraseFromMapArray;
		//���߳�ʹ����Ҫʹ����
		WfirstRWLock RayCastArrayLock;
		std::unordered_map<ptr_t, std::shared_ptr<std::vector<FVector>>> RayCastArray;
		//���߳�ʹ����Ҫʹ����
		WfirstRWLock RayCastResultArrayLock;
		std::unordered_map<ptr_t, std::shared_ptr<std::vector<bool>>> RayCastResultArray;
		//��ÿ��ѭ�����µ�ָ��������鲢����һ�ֿ�����ʱ������������бȽϡ��Ƴ�
		WfirstRWLock CurrentSceneActorLock;
		std::unordered_map<ptr_t, std::shared_ptr<int>> CurrentSceneActorWithLock;
		//����������ڴ汣�����������
		WfirstRWLock CurrentAllocateMemoryLock;
		std::unordered_map<void*, std::shared_ptr<int>> CurrentAllocateMemory;
		//��Ҫ���ٵ��ڴ汣�����������
		WfirstRWLock CurrentDeleteMemoryLock;
		std::unordered_map<void*, std::shared_ptr<int>> CurrentDeleteMemory;

	};
}


#endif // PHYSICS_MANAGER_H